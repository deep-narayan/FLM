import pandas as pd
import requests as req
import json
import numpy as np
import matplotlib as plt
import pandas as pd
import html_to_json


def plant_analyse(num):

    url="https://gprs.embarkrms.com/request.php?&number={}".format(num)

    a=req.get(url)
    

    #a
    #check Working

    txt=a.content

    #txt

    a.headers.get('content-type')

    newtxt=a.text
    newtxt=newtxt.strip()
    newtxt=newtxt.replace('<pre>','')
    newtxt=newtxt.replace('</pre>','')

    f = open("newfile.json", "w")
    f.write(newtxt)
    f.close()

        

    with open('newfile.json', encoding='utf-8') as fh:
        data = json.load(fh)

   

    newdata=data['']['{}'.format(num)]

    #newdata

    ke=newdata.keys()

    #ke
    s=[]
    for i in ke:
        for j in newdata[i]:
            s.append(j)
        
    #j
    inde=j.keys()

    df=pd.DataFrame(s)

    newk=[]
    for i in list(df):
        a=i.split(" ")
        if len(a)>=2:
            newk.append(a[0])
        else:
            newk.append(i)

    df = df.set_axis(newk, axis=1)

    #df.head(n=5)

    df=df.replace('LPBR',00.00)
    df=df.replace('-',0)

    df['Date'] = pd.to_datetime(df['Date'], infer_datetime_format=False,format="%d-%m-%y")
    df= df.astype({'COND': 'float64','FR1': 'float64','FR2': 'float64','VOL1': 'float64','VOL2': 'float64','LVL1': 'float64','LVL2': 'float64'})    

    

    #df['DnT']=df['Date']+" "+df['Time']

    file_name = '{}.xlsx'.format(num)
  
    df.to_excel(file_name)

    #print(df['Date'])

    newdf=df[['Date','Time','COND','FR1','FR2','VOL1','VOL2','LVL1','LVL2']]
    daydf=newdf.groupby(pd.Grouper(key='Date', axis=0)).max()
    daydf=daydf.reset_index()

    monthdf=newdf.groupby(pd.Grouper(key='Date',freq="M",axis=0)).mean()
    monthdf=monthdf.reset_index()
    monthdf['Date'] = monthdf['Date'].dt.month_name()

    yeardf=newdf.groupby(pd.Grouper(key='Date',freq="Y",axis=0)).mean()
    yeardf=yeardf.reset_index()



    avol1= df['VOL1'].mean(axis=0, skipna=True)
    avol2= df['VOL2'].mean(axis=0, skipna=True)
    afr1= df['FR1'].mean(axis=0, skipna=True)
    afr2= df['FR2'].mean(axis=0, skipna=True)

    avol1 = "{:.2f}".format(avol1)
    avol2 = "{:.2f}".format(avol2)
    afr1 = "{:.2f}".format(afr1)
    afr2 = "{:.2f}".format(afr2)

    

    df2=df.head(n=12)


    return df2,avol1,avol2,afr1,afr2,daydf,monthdf,yeardf
