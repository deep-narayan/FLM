from django.apps import AppConfig


class CaretakerConfig(AppConfig):
    name = 'caretaker'
