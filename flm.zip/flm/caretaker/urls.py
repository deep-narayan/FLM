
from django.urls import path,include
from . import views


app_name = "caretaker"

urlpatterns = [
    path('',views.dashboard),
    path('logout/',views.logout_call ,name='logout'),
    path('analyse/<id>/',views.analyse,name='analyse'),
]
