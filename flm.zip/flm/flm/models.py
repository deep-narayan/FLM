from django.db import models
from django.contrib.auth.models import User


class User_addon(models.Model):
	def __str__(self):
		na= self.user.username +"-"+self.utype
		return na

	class Meta():
		unique_together = ('user', 'aadhar')


			
	user = models.OneToOneField(User, on_delete=models.CASCADE)
	mobileno = models.CharField(max_length=15)
	dob=models.DateField(auto_now=False) 
	gender=models.CharField(max_length=10)
	address=models.CharField(max_length=200)
	aadhar=models.CharField(max_length=20)
	utype=models.CharField(max_length=20)







