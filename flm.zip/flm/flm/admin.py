from django.contrib import admin
from .models import User_addon


admin.site.register(User_addon)