from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login, logout
from .models import User_addon
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from file import FLM_final
import numpy as np
from django.contrib.auth.decorators import login_required


def home(request):
	if request.method=='POST':
		u=request.POST['username']
		p=request.POST['password']
		try:
			selUser = authenticate(username=u, password=p)
		except:
			return render(request,'error.html')

		if selUser:
			login(request, selUser)
			uObj = User_addon.objects.get(user__username=request.user)
			if uObj.utype == "caretaker":
				return redirect('caretaker/')
			elif uObj.utype == "owner":
				return redirect('owner/')

			elif uObj.utype == "suadmin":
				return redirect('suadmin/')

		else:
			return render(request,'error.html')


	return render(request,'index.html')







