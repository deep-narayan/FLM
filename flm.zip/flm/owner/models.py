from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class Site(models.Model):
	def __str__(self):
		return self.name

	oid=models.ForeignKey(User, on_delete=models.DO_NOTHING)
	ids=models.CharField(max_length=10,unique=True)
	name=models.CharField(max_length=30)
	cap1=models.FloatField()
	cap2=models.FloatField()
	status=models.IntegerField(default=0)


class ctr(models.Model):

	uid=models.ForeignKey(User,on_delete=models.DO_NOTHING)
	sid=models.ForeignKey(Site,on_delete=models.DO_NOTHING)
