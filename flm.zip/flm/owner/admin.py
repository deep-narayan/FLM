from django.contrib import admin
from .models import Site,ctr

# Register your models here.
admin.site.register(Site)
admin.site.register(ctr)
