from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.http import HttpResponseRedirect
from flm.models import User_addon
from .models import Site,ctr
from django.contrib.auth.decorators import login_required
from file import FLM_final
import numpy as np

# Create your views here.
@login_required
def dashboard(request):
	rname=request.user
	uObj = User_addon.objects.get(user__username=request.user)
	utype1=str(uObj.utype).upper()
	ll=rname.last_login

	return render(request,'owner.html',{'name':str(rname).upper(),'deg':utype1,'ull':ll})


def logout_call(request):
	logout(request)
	return redirect('/')

@login_required
def createsite(request):
	oid1=request.user
	if request.method=='POST':
		no1=request.POST['sno']
		name1=request.POST['sname']
		t1=request.POST['t1c']
		t2=request.POST['t2c']


		s=Site(oid=oid1,ids=no1,name=name1,cap1=t1,cap2=t2)
		s.save()

		return redirect('/owner')



	return render(request,'createsite.html')

@login_required
def addctr(request):
	ss1=Site.objects.filter(oid=request.user).filter(status=0)
	#print(ss1)
	if request.method=='POST':
		fname=request.POST['nm1']
		lname=request.POST['nm2']
		email=request.POST['email']
		username=request.POST['username']
		password=request.POST['pwd']
		gen=request.POST['gen']
		add=request.POST['add']
		usertype='caretaker'
		mobileno1=request.POST['mobileno']
		adhar=request.POST['adhar']
		dob1=request.POST['dateob']
		site=request.POST['site']

		u = User(first_name=fname, last_name=lname, username=username, password=make_password(password), email=email)
		u.save()
		up = User_addon(user=u,utype=usertype,gender=gen,address=add,aadhar=adhar,dob=dob1,mobileno=mobileno1)
		up.save()

		Site.objects.filter(name=site).update(status=1)
		sid2=Site.objects.get(name=site)

		ups=ctr(uid=u,sid=sid2)
		ups.save()
		return redirect('/owner')

	return render(request,'addctr.html',{'ss':ss1})

@login_required
def sitesview(request):
	ss2=Site.objects.filter(oid=request.user)
	return render(request,'sitesview.html',{'site':ss2})

@login_required
def plantview(request):
	ss2=Site.objects.filter(oid=request.user)

	if request.method=='POST':
		sn=request.POST['site']
		#print(sn)
		sn=int(sn)

		return redirect('/owner/analyse/{}'.format(sn))

	return render(request,'plantview.html',{'site':ss2})

@login_required
def report(request):
	ss2=Site.objects.all()
	return render(request,'report.html',{'site':ss2})


@login_required
def editsite(request):
	return render(request,'createsite.html') 


@login_required
def analyse(request,id):
	
	df,avol1,avol2,afr1,afr2=FLM_final.plant_analyse(id)

	x=np.array(df['Date'])
	j1=np.array(df['VOL1'])
	g1=np.array(df['VOL2'])
	h1=np.array(df['FR1'])
	k1=np.array(df['FR2'])
	t1=np.array(df['COND'])


	j1 = [float(x) for x in j1 ]
	g1 = [float(x) for x in g1 ]
	h1 = [float(x) for x in h1 ]
	k1 = [float(x) for x in k1 ]
	t1 = [float(x) for x in t1 ]

	#print(x,y)

	lvl1=df['LVL1'][0]
	lvl2=df['LVL2'][0]

	a=Site.objects.get(ids=id)
	max1=a.cap1
	max2=a.cap2	

	return render(request,'oplantanalyse.html',{'x':x,'j':j1,'g':g1,'h':h1,'k':k1,'t':t1,'cap1':max1,'cap2':max2,'le1':lvl1,'le2':lvl2,'card1':avol1,'card2':avol2,'card3':afr1,'card4':afr2})