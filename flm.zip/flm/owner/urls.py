
from django.urls import path,include
from . import views

app_name = "owner"

urlpatterns = [
    path('',views.dashboard),
    path('logout/',views.logout_call ,name='logout'),
    path('createsite/',views.createsite,name='createsite'),
    path('editsite/',views.editsite,name='editsite'),
    path('addctr/',views.addctr,name='addctr'),
    path('sitesview/',views.sitesview,name='sitesview'),
    path('plantview/',views.plantview,name='plantview'),
    path('report/',views.report,name='report'),
    path('analyse/<id>/',views.analyse,name='analyse'),
]
