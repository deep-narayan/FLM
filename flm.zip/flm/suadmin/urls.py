
from django.urls import path
from . import views


app_name = "suadmin"

urlpatterns = [
    path('',views.dashboard),
    path('logout/',views.logout_call ,name='logout'),
    path('sitesview/',views.sitesview,name='sitesview'),
    path('addowner/',views.addowner,name='addowner'),
    path('oaddctr/',views.oaddctr,name='oaddctr'),
    path('analyse/<id>/',views.analyse,name='analyse'),

]
