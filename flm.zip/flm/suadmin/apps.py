from django.apps import AppConfig


class SuadminConfig(AppConfig):
    name = 'suadmin'
