const input = document.querySelectorAll(".form-control");
function AddClass(){
    let parent = this.parentNode.parentNode;
    parent.classList.remove("focus");
}
function RemoveClass(){
    let parent = this.parentNode.parentNode;
    if(this.value ==''){
        parent.classList.remove("focus");
    }
}
input.forEach(input=>{
    input.addEventListener("focus",AddClass);
    input.addEventListener("focus",RemoveClass);
})